package UT6_Platadorma_Streaming;

public enum TipoContenido {
	
	Musica(),
	Pelicula(),
	Serie,
	Podcast;
	
	/*private final String nombre;
	
	TipoContenido(String nombre){
		this.nombre = nombre;
	}*/
	
}