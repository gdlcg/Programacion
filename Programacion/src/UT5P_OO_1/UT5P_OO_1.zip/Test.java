package UT5P_OO_1;

public class Test {

}
